<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800">KHS Mahasiswa</h1>

	<!-- Main Content goes here -->

	

	<p><?php echo e($khs->status == 0 ? 'Tambah' : 'Edit'); ?> Nilai Untuk KHS <?php echo e($student->name); ?> Semester <?php echo e($khs->semester); ?></p>

	<form action="<?php echo e(route('khss.update', $khs->id)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>

		<table class="table-bordered table-stripped table">
			<thead>
				<tr>
					<th>No</th>
					<th>Kode Matkul</th>
					<th>Nama Matkul</th>
					<th>SKS</th>
					<th>Nilai</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $khs->khs_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td scope="row"><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($subject->subject->kode_matkul); ?></td>
						<td><?php echo e($subject->subject->name); ?></td>
						<td><?php echo e($subject->subject->sks); ?></td>
						<td>
							<div class="form-check form-check-inline">
								<input type="radio" name="grades[<?php echo e($subject->id); ?>]" id="grade_A_<?php echo e($subject->id); ?>" value="A"
									<?php echo e($subject->grade === 'A' ? 'checked' : ''); ?>>
								<label class="form-check-label" for="grade_A_<?php echo e($subject->id); ?>">A</label>
							</div>
							<div class="form-check form-check-inline">
								<input type="radio" name="grades[<?php echo e($subject->id); ?>]" id="grade_Bplus_<?php echo e($subject->id); ?>" value="B+"
									<?php echo e($subject->grade === 'B+' ? 'checked' : ''); ?>>
								<label class="form-check-label" for="grade_Bplus_<?php echo e($subject->id); ?>">B+</label>
							</div>
							<div class="form-check form-check-inline">
								<input type="radio" name="grades[<?php echo e($subject->id); ?>]" id="grade_B_<?php echo e($subject->id); ?>" value="B"
									<?php echo e($subject->grade === 'B' ? 'checked' : ''); ?>>
								<label class="form-check-label" for="grade_B_<?php echo e($subject->id); ?>">B</label>
							</div>
							<div class="form-check form-check-inline">
								<input type="radio" name="grades[<?php echo e($subject->id); ?>]" id="grade_Cplus_<?php echo e($subject->id); ?>" value="C+"
									<?php echo e($subject->grade === 'C+' ? 'checked' : ''); ?>>
								<label class="form-check-label" for="grade_Cplus_<?php echo e($subject->id); ?>">C+</label>
							</div>
							<div class="form-check form-check-inline">
								<input type="radio" name="grades[<?php echo e($subject->id); ?>]" id="grade_D_<?php echo e($subject->id); ?>" value="D"
									<?php echo e($subject->grade === 'D' ? 'checked' : ''); ?>>
								<label class="form-check-label" for="grade_D_<?php echo e($subject->id); ?>">D</label>
							</div>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<button type="submit" class="btn btn-primary">Simpan</button>
	</form>

	

	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/khs/show.blade.php ENDPATH**/ ?>