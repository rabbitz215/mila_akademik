<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	<table id="dataTable" class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>NIM</th>
				<th>Nama</th>
				<th>Kelas</th>
				<th>Program Studi</th>
				<th>Semester</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $khss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
					$student = $khs->student;
				?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($student->nim); ?></td>
					<td><?php echo e($student->name); ?></td>
					<td><?php echo e($student->class); ?></td>
					<td><?php echo e($student->study_program->name); ?></td>
					<td><?php echo e($khs->semester); ?></td>
					<td><?php echo e($khs->status == 0 ? 'Belum Dinilai' : 'Sudah Dinilai'); ?>

						(IPK :
						<?php echo e($khs->status == 1 ? number_format($khs->calculated_grade, 2) : '0'); ?><?php echo e($khs->khs_subjects->contains('grade', 'D') ? ', Tidak lulus, Total Nilai D : ' . $khs->khs_subjects->where('grade', 'D')->count() : ''); ?>)
					</td>
					<td>
						<div class="d-flex">
							<?php if($khs->status == 1): ?>
								<a href="<?php echo e(route('khss.cetak', $khs->id)); ?>" class="btn btn-sm btn-primary mr-2">Cetak
								</a>
							<?php endif; ?>
							<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
								<a href="<?php echo e(route('khss.show', $khs->id)); ?>"
									class="btn btn-sm btn-primary mr-2"><?php echo e($khs->status == 0 ? 'Tambah' : 'Edit'); ?> Nilai
								</a>
								<form action="<?php echo e(route('khss.destroy', $khs->id)); ?>" method="post">
									<?php echo csrf_field(); ?>
									<?php echo method_field('delete'); ?>
									<button type="submit" class="btn btn-sm btn-danger"
										onclick="return confirm('Are you sure to delete this?')">Delete</button>
								</form>
							<?php endif; ?>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/khs/list.blade.php ENDPATH**/ ?>