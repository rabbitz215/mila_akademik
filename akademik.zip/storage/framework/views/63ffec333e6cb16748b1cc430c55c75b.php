<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	

	<form action="<?php echo e(route('krs.update_approval_mahasiswa', $krs->id)); ?>" method="post">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<table class="table-bordered table-stripped table">
			<thead>
				<tr>
					<th>No</th>
					<th>Kode Matkul</th>
					<th>Nama Matkul</th>
					<th>SKS</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $krs->krs_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td scope="row"><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($subject->subject->kode_matkul); ?></td>
						<td><?php echo e($subject->subject->name); ?></td>
						<td><?php echo e($subject->subject->sks); ?></td>
						<td>
							<div class="form-check">
								<input type="checkbox" class="form-check-input" name="approves[]" value="<?php echo e($subject->id); ?>"
									id="approveCheckbox<?php echo e($loop->iteration); ?>">
								<label class="form-check-label" for="approveCheckbox<?php echo e($loop->iteration); ?>">Setuju</label>
							</div>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<button type="submit" id="submitBtn" class="btn btn-primary" disabled>Submit</button>
	</form>

	<!-- End of Main Content -->
	<script>
		const checkboxes = document.querySelectorAll('input[name="approves[]"]');
		const submitButton = document.getElementById('submitBtn');

		checkboxes.forEach((checkbox) => {
			checkbox.addEventListener('change', () => {
				const allChecked = [...checkboxes].every((checkbox) => checkbox.checked);
				submitButton.disabled = !allChecked;
			});
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/krs/mahasiswa.blade.php ENDPATH**/ ?>