<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	

	<table id="dataTable" class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>NIM</th>
				<th>Nama</th>
				<th>Kelas</th>
				<th>Program Studi</th>
				<th>Semester</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $krss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($krs->student->nim); ?></td>
					<td><?php echo e($krs->student->name); ?></td>
					<td><?php echo e($krs->student->class ?: '-'); ?></td>
					<td><?php echo e($krs->student->study_program->name); ?></td>
					<td><?php echo e($krs->semester); ?></td>
					<td><?php echo e($krs->status_label); ?></td>
					<td>
						<div class="d-flex">
							<?php if($krs->status == \App\Krs::NEED_APPROVAL_KRS): ?>
								<a href="<?php echo e(route('krss.edit', $krs->id)); ?>" class="btn btn-sm btn-primary mr-2">Approve</a>
							<?php endif; ?>
							<?php if($krs->status == \App\Krs::APPROVED_KRS): ?>
								<a href="<?php echo e(route('krs.cetak', $krs->id)); ?>" class="btn btn-sm btn-primary mr-2">Cetak</a>
							<?php endif; ?>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/krs/list.blade.php ENDPATH**/ ?>