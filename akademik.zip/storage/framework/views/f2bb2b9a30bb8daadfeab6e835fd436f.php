<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Dashboard')); ?></h1>

	<?php if(session('success')): ?>
		<div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
			<?php echo e(session('success')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('status')): ?>
		<div class="alert alert-success border-left-success" role="alert">
			<?php echo e(session('status')); ?>

		</div>
	<?php endif; ?>

	<div class="row">
		<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Earnings (Monthly)</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800">$40,000</div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'mahasiswa')): ?>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Kelas</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800"><?php echo e(auth()->user()->student->class); ?></div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total KRS</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800">
									<?php echo e(\App\Krs::where('student_id', auth()->user()->student->id)->count()); ?></div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total KHS</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800">
									<?php echo e(\App\Khs::where('student_id', auth()->user()->student->id)->count()); ?></div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dosen')): ?>
			<?php
				$dosen = auth()->user()->dosen;
				$dosenClassStrings = $dosen->kelas->map(function ($kelas) {
				    return $kelas->tingkat . $kelas->kelas;
				});
				$student_groups = \App\Student::whereIn('class', $dosenClassStrings)
				    ->get()
				    ->groupBy('class');
				$totalStudents = $student_groups
				    ->map(function ($students) {
				        return $students->count();
				    })
				    ->sum();
				$totalStudentsMale = $student_groups
				    ->map(function ($students) {
				        return $students->where('gender', 'Laki-Laki')->count();
				    })
				    ->sum();
				$totalStudentsFemale = $student_groups
				    ->map(function ($students) {
				        return $students->where('gender', 'Perempuan')->count();
				    })
				    ->sum();
			?>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total Siswa Semua Kelas Anda</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800">
									<?php echo e($totalStudents); ?></div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total Siswa Laki-Laki Semua Kelas Anda
								</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800">
									<?php echo e($totalStudentsMale); ?></div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-primary h-100 py-2 shadow">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total Siswa Perempuan Semua Kelas Anda
								</div>
								<div class="h5 font-weight-bold mb-0 text-gray-800">
									<?php echo e($totalStudentsFemale); ?></div>
							</div>
							<div class="col-auto">
								<i class="fas fa-calendar fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/home.blade.php ENDPATH**/ ?>