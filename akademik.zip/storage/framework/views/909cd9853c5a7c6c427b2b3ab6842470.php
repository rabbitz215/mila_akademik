<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	<a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary mb-3">Mahasiswa +</a>
	<a href="<?php echo e(route('students.acak')); ?>" class="btn btn-primary mb-3">Acak Kelas</a>

	<table id="dataTable" class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>NIM</th>
				<th>Nama</th>
				<th>Kelas</th>
				<th>Program Studi</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($student->nim); ?></td>
					<td><?php echo e($student->name); ?></td>
					<td><?php echo e($student->class ?: '-'); ?></td>
					<td><?php echo e($student->study_program ? $student->study_program->name : '-'); ?></td>
					<td>
						<div class="d-flex">
							<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
								<?php if(!$student->class == null): ?>
									<a href="#" class="btn btn-sm btn-primary krs-btn mr-2" data-id="<?php echo e($student->id); ?>">Buat KRS</a>
									<?php if($student->krss->count() > 0): ?>
										<a href="#" class="btn btn-sm btn-primary khs-btn mr-2" data-id="<?php echo e($student->id); ?>"
											data-options='<?php echo json_encode($student->krss->where('status', 2)->pluck('semester')->toArray(), 512) ?>'>Buat
											KHS</a>
									<?php endif; ?>
								<?php endif; ?>
							<?php endif; ?>
							<a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-sm btn-primary mr-2">Edit</a>
							<form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="post">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-sm btn-danger"
									onclick="return confirm('Are you sure to delete this?')">Delete</button>
							</form>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<div class="modal fade" id="krsModal" tabindex="-1" role="dialog" aria-labelledby="krsModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="krsModalLabel">Buat KRS (Kartu Rencana Studi)</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form id="krsModalForm" action="" method="post">
						<?php echo csrf_field(); ?>
						<!-- Add a select dropdown for selecting semesters -->
						<div class="form-group">
							<label for="semester">Semester</label>
							<select class="form-control" id="semester" name="semester">
								<?php for($i = 1; $i <= 8; $i++): ?>
									<option value="<?php echo e($i); ?>">Semester <?php echo e($i); ?></option>
								<?php endfor; ?>
							</select>
						</div>

						<button type="submit" class="btn btn-primary">Buat</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="khsModal" tabindex="-1" role="dialog" aria-labelledby="khsModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="khsModalLabel">Buat KHS (Kartu Hasil Ujian)</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form id="khsModalForm" action="" method="post">
						<?php echo csrf_field(); ?>
						<!-- Add a select dropdown for selecting semesters -->
						<div class="form-group">
							<label for="semester">Semester</label>
							<select id="selectSemester" class="form-control" name="semester">
								<!-- Options will be populated here -->
							</select>
						</div>

						<button type="submit" class="btn btn-primary">Buat</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			// Add a click event handler for the 'Edit' button
			$('.krs-btn').on('click', function(e) {
				e.preventDefault();

				// Get the student ID from the data-id attribute
				var studentId = $(this).data('id');

				// Set the student ID in the modal form action
				$('#krsModalForm').attr('action', "<?php echo e(route('students.make_krs', '')); ?>/" + studentId);

				// Show the modal
				$('#krsModal').modal('show');
			});

			$('.khs-btn').on('click', function(e) {
				e.preventDefault();

				// Get the student ID from the data-id attribute
				var studentId = $(this).data('id');
				var options = $(this).data('options');

				populateSelectOptions(options);

				// Set the student ID in the modal form action
				$('#khsModalForm').attr('action', "<?php echo e(route('students.make_khs', '')); ?>/" + studentId);

				// Show the modal
				$('#khsModal').modal('show');
			});

			function populateSelectOptions(options) {
				var selectSemester = $('#selectSemester');
				selectSemester.empty(); // Clear previous options
				$.each(options, function(index, semester) {
					selectSemester.append('<option value="' + semester + '">Semester ' + semester +
						'</option>');
				});
			}
		});
	</script>
	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
	<?php if(session('success')): ?>
		<div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
			<?php echo e(session('success')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('warning')): ?>
		<div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
			<?php echo e(session('warning')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('error')): ?>
		<div class="alert alert-danger border-left-danger alert-dismissible fade show" role="alert">
			<?php echo e(session('error')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('status')): ?>
		<div class="alert alert-success border-left-success" role="alert">
			<?php echo e(session('status')); ?>

		</div>
	<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/student/list.blade.php ENDPATH**/ ?>