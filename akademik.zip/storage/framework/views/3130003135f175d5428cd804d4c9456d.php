<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	<a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-primary mb-3">Mata Kuliah +</a>

	<table id="dataTable" class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>SKS</th>
				<th>Prodi</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($subject->name); ?></td>
					<td><?php echo e($subject->sks); ?></td>
					<td><?php echo e($subject->study_program->name); ?></td>
					<td>
						<div class="d-flex">
							<a href="<?php echo e(route('subjects.edit', $subject->id)); ?>" class="btn btn-sm btn-primary mr-2">Edit</a>
							<form action="<?php echo e(route('subjects.destroy', $subject->id)); ?>" method="post">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-sm btn-danger"
									onclick="return confirm('Are you sure to delete this?')">Delete</button>
							</form>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/subject/list.blade.php ENDPATH**/ ?>