<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	

	<div class="">
		<div class="row">
			<div class="col-lg-6">
				<div class="form-group focused">
					<label class="form-control-label" for="name">Name<span class="small text-danger">*</span></label>
					<input disabled type="text" id="name" class="form-control" name="name" placeholder="Name"
						value="<?php echo e($studyProgram->name); ?>">
				</div>
			</div>
			
		</div>
	</div>

	<a href="<?php echo e(route('study_programs.create_semester_subject', $studyProgram->id)); ?>" class="btn btn-primary mb-3">Mata
		Kuliah +</a>

	<table class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Kuliah</th>
				<th>Semester</th>
				<th>SKS</th>
				<th>Jam</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $studyProgram->semester_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($subject->subject->name); ?></td>
					<td><?php echo e($subject->semester); ?></td>
					<td><?php echo e($subject->subject->sks); ?></td>
					<td><?php echo e($subject->hour ?: '-'); ?></td>
					<td>
						<div class="d-flex">
							<a href="<?php echo e(route('study_programs.edit_semester_subject', $subject->id)); ?>"
								class="btn btn-sm btn-primary mr-2">Edit</a>
							<form action="<?php echo e(route('study_programs.destroy_semester_subject', $subject->id)); ?>" method="post">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-sm btn-danger"
									onclick="return confirm('Are you sure to delete this?')">Delete</button>
							</form>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	

	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/study_program/show.blade.php ENDPATH**/ ?>