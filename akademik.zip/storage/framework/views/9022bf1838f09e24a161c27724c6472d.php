<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	<div class="row">
		<div class="col-xl-3 col-md-6 mb-4">
			<div class="card border-left-primary h-100 py-2 shadow">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total Siswa Kelas <?php echo e($kelas); ?></div>
							<div class="h5 font-weight-bold mb-0 text-gray-800">
								<?php echo e($students->count()); ?></div>
						</div>
						<div class="col-auto">
							<i class="fas fa-calendar fa-2x text-gray-300"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 col-md-6 mb-4">
			<div class="card border-left-primary h-100 py-2 shadow">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total Siswa Laki-Laki Kelas
								<?php echo e($kelas); ?></div>
							<div class="h5 font-weight-bold mb-0 text-gray-800">
								<?php echo e($students->where('gender', 'Laki-Laki')->count()); ?></div>
						</div>
						<div class="col-auto">
							<i class="fas fa-calendar fa-2x text-gray-300"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 col-md-6 mb-4">
			<div class="card border-left-primary h-100 py-2 shadow">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total Siswa Perempuan Kelas
								<?php echo e($kelas); ?></div>
							<div class="h5 font-weight-bold mb-0 text-gray-800">
								<?php echo e($students->where('gender', 'Perempuan')->count()); ?></div>
						</div>
						<div class="col-auto">
							<i class="fas fa-calendar fa-2x text-gray-300"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 col-md-6 mb-4">
			<div class="card border-left-primary h-100 py-2 shadow">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="font-weight-bold text-primary text-uppercase mb-1 text-xs">Total KRS Siswa Butuh Approval Kelas
								<?php echo e($kelas); ?></div>
							<div class="h5 font-weight-bold mb-0 text-gray-800">
								<?php echo e($approval_krss); ?></div>
						</div>
						<div class="col-auto">
							<i class="fas fa-calendar fa-2x text-gray-300"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<table id="dataTable" class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>NIM</th>
				<th>Nama</th>
				<th>Kelas</th>
				<th>Program Studi</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($student->nim); ?></td>
					<td><?php echo e($student->name); ?></td>
					<td><?php echo e($student->class ?: '-'); ?></td>
					<td><?php echo e($student->study_program->name); ?></td>
					<td>
						<div class="d-flex">
							<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
								<a href="#" class="btn btn-sm btn-primary krs-btn mr-2" data-id="<?php echo e($student->id); ?>">Buat KRS</a>
								<a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-sm btn-primary mr-2">Edit</a>
								<form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="post">
									<?php echo csrf_field(); ?>
									<?php echo method_field('delete'); ?>
									<button type="submit" class="btn btn-sm btn-danger"
										onclick="return confirm('Are you sure to delete this?')">Delete</button>
								</form>
							<?php endif; ?>
							<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dosen')): ?>
								<?php if($student->krss()->latest()->first()): ?>
									<?php if($student->krss()->latest()->first()->status == 2): ?>
										<button class="btn btn-sm btn-success disabled ml-2" style="cursor:default;">Sudah di approve</button>
									<?php elseif($student->krss()->latest()->first()->status == 1): ?>
										<form action="<?php echo e(route('krs.update_approval_dosen',$student->krss()->latest()->first('id'))); ?>" method="post">
											<?php echo csrf_field(); ?>
											<?php echo method_field('put'); ?>
											<button type="submit" class="btn btn-sm btn-primary ml-2"
												onclick="return confirm('Apakah anda yakin?')">Approve & Siap Cetak
												KRS</button>
										</form>
									<?php endif; ?>
								<?php else: ?>
									<button class="btn btn-sm btn-primary disabled ml-2">Approve & Siap Cetak
										KRS</button>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<div class="modal fade" id="krsModal" tabindex="-1" role="dialog" aria-labelledby="krsModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="krsModalLabel">Buat KRS</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form id="krsModalForm" action="" method="post">
						<?php echo csrf_field(); ?>
						<!-- Add a select dropdown for selecting semesters -->
						<div class="form-group">
							<label for="semester">Semester</label>
							<select class="form-control" id="semester" name="semester">
								<?php for($i = 1; $i <= 8; $i++): ?>
									<option value="<?php echo e($i); ?>">Semester <?php echo e($i); ?></option>
								<?php endfor; ?>
							</select>
						</div>

						<button type="submit" class="btn btn-primary">Buat</button>
					</form>
				</div>
			</div>
		</div>
	</div>

	<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			// Add a click event handler for the 'Edit' button
			$('.krs-btn').on('click', function(e) {
				e.preventDefault();

				// Get the student ID from the data-id attribute
				var studentId = $(this).data('id');

				// Set the student ID in the modal form action
				$('#krsModalForm').attr('action', "<?php echo e(route('students.make_krs', '')); ?>/" + studentId);

				// Show the modal
				$('#krsModal').modal('show');
			});
		});
	</script>
	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
	<?php if(session('success')): ?>
		<div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
			<?php echo e(session('success')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('warning')): ?>
		<div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
			<?php echo e(session('warning')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('error')): ?>
		<div class="alert alert-danger border-left-danger alert-dismissible fade show" role="alert">
			<?php echo e(session('error')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

	<?php if(session('status')): ?>
		<div class="alert alert-success border-left-success" role="alert">
			<?php echo e(session('status')); ?>

		</div>
	<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/krs/dosen.blade.php ENDPATH**/ ?>