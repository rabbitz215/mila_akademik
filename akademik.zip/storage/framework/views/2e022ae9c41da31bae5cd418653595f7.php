<?php $__env->startSection('main-content'); ?>
	<!-- Page Heading -->
	<h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Blank Page')); ?></h1>

	<!-- Main Content goes here -->

	<a href="<?php echo e(route('kelass.create')); ?>" class="btn btn-primary mb-3">Kelas +</a>

	<table id="dataTable" class="table-bordered table-stripped table">
		<thead>
			<tr>
				<th>No</th>
				<th>Kelas</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $kelass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td scope="row"><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($kelas->tingkat . $kelas->kelas); ?></td>
					<td>
						<div class="d-flex">
							<a href="<?php echo e(route('kelass.show', $kelas->id)); ?>" class="btn btn-sm btn-primary mr-2">Show</a>
							<a href="<?php echo e(route('kelass.edit', $kelas->id)); ?>" class="btn btn-sm btn-primary mr-2">Edit</a>
							<form action="<?php echo e(route('kelass.destroy', $kelas->id)); ?>" method="post">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-sm btn-danger"
									onclick="return confirm('Are you sure to delete this?')">Delete</button>
							</form>
						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\akademik\resources\views/kelas/list.blade.php ENDPATH**/ ?>